import 'package:flutter/material.dart';

class Quest extends StatelessWidget {
  final String texto;

  Quest(this.texto);

  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.all(10),
      child: Text(
        texto,
        style: TextStyle(fontSize: 30),
        textAlign: TextAlign.center,
      ),
    );
  }
}
