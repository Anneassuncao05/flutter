import 'package:flutter/material.dart';
import './questionario.dart';

void main() {
  runApp(TrabalhoComponentes());
}

class TrabalhoComponentes extends StatefulWidget {
  @override
  State<TrabalhoComponentes> createState() => _TrabalhoComponentesState();
}

class _TrabalhoComponentesState extends State<TrabalhoComponentes> {
  var pergunta_Atual = 0;
  var cor = Colors.blue;
  List<String> respostas = [];

  final List<Map<String, Object>> perguntas = [
    {
      "texto": "Qual sua série favorita?",
      "respostas": ["Black Mirror", "La casa de Papel", "TVD", "Outra"]
    },
    {
      "texto": "Qual é o seu filme favorito?",
      "respostas": ["Magico de Oz", "Titanic", "Avatar", "Outro"]
    },
    {
      "texto": "Qual é o seu esporte favorito?",
      "respostas": ["Vôlei", "Basquete", "Futebol", "Luta"]
    },
  ];

  bool get temPergunta {
    return pergunta_Atual < perguntas.length;
  }

  void acao(String resposta) {
    setState(() {
      respostas.add(resposta);
      pergunta_Atual++;
    });
    print(pergunta_Atual);
  }

  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: temPergunta
              ? Text(perguntas[pergunta_Atual]["texto"].toString())
              : Text("terminou"),
        ),
        body: temPergunta
            ? Questionario(
                perguntas: perguntas,
                pergunta_Atual: pergunta_Atual,
                onResposta_Selecionada: (resposta) => acao(resposta),
              )
            : Column(
                children: [
                  Text("resultado:"),
                  SizedBox(height: 30),
                  Text("respostas a seguir:"),
                  Column(
                    children:
                        respostas.map((resposta) => Text(resposta)).toList(),
                  ),
                ],
              ),
      ),
    );
  }
}
