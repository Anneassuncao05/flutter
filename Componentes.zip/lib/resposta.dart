import 'package:flutter/material.dart';

class Resp extends StatelessWidget {
  final String texto;
  final void Function() Selecionado;

  Resp(this.texto, this.Selecionado);

  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(top: 15, bottom: 15),
      child: ElevatedButton(onPressed: Selecionado, child: Text(this.texto)),
    );
  }
}
