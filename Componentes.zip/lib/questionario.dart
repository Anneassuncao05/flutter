import 'package:flutter/material.dart';
import './questao.dart';
import './resposta.dart';

class Questionario extends StatelessWidget {
  final List<Map<String, Object>> perguntas;
  final int pergunta_Atual;
  final Function() onResposta_Selecionada;

  Questionario({
    required this.perguntas,
    required this.pergunta_Atual,
    required this.onResposta_Selecionada,
  });

  @override
  Widget build(BuildContext context) {
    List<Widget> respostas = [];
    for (var resposta
        in perguntas[pergunta_Atual]['respostas'] as List<String>) {
      respostas.add(
        Resp(resposta, onResposta_Selecionada),
      );
    }

    return Column(
      children: [
        Quest(perguntas[pergunta_Atual]['texto'].toString()),
        ...respostas,
      ],
    );
  }
}
